# Evaluation and optimization
