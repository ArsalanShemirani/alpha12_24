# Backtesting and simulation
