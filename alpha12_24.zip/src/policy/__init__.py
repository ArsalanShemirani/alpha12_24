# Trading policies and decision making
